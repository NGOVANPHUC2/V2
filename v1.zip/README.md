# Brainfuck Tunnel - Psiphon Pro Go Version


**Android cài đặt (Termux)**

    pkg install git -y && git clone https://github.com/thuanht567/vss && cd vss && chmod +x * && echo 'PATH="$PATH:$HOME/vss"' >> $HOME/.bashrc && source $HOME/.bashrc && t


 Run
----
***Android chạy hack4G lệnh (Termux)***
t

# gõ chữ t xong emter để chạy chương trình hack 4g 



#### gõ tx để fix lỗi chương trình hack

##### app socksdroid
https://github.com/thuanht567/vss/raw/master/SocksDroid-termi.apk


### Pro Version


Note
----

- Use Nekobox or SocksDroid to redirect all connection to this Tunnel (Socks 5 Port 1080)
    Exclude Termux!

